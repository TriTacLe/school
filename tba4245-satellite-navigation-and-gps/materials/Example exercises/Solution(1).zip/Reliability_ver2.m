
clear;

% Reading coordinates from file: input.KOF 
[fid mld] = fopen('input.KOF','r')	% open file for reading, has to be on the same folder as this script% 
[kofkode,pktnavn,sosikode,nord,ost,hoyde] = textread('input.KOF','%f %s %f %f %f %f','headerlines',0);
status = fclose(fid)

% [rows columns] = size(x)
n_points = length(nord)

for i=1:n_points
    x(i,1) = nord(i);
    y(i,1) = ost(i);
    h(i,1) = hoyde(i); 
end

% Planned observations, columns 1)station s 2) target t 3)Horizontal distance

% No random errors obs_mat = [
% 1   2	200.0000   
% 1	3	223.6068
% 1	4	100.0000
% 2	1	200.0000
% 2	3	100.0000
% 2	4	223.6068
% 3	1	223.6068
% 3	2	100.0000
% 3	4	200.0000
% 4	1	100.0000
% 4	2	223.6068
% 4	3	200.0000 ]

obs_mat = [         % Added some random errors
1   2	200.0010    % added 1mm
1	3	223.6078    % added 1mm
1	4	100.0010    % added 1mm
2	1	199.9990    % -1
2	3	 99.9990    % -1
2	4	223.6058    % -1
3	1	223.6058    % -1
3	2	 99.9990    % -1
3	4	199.9990    % -1
4	1	100.0010    % +1
4	2	223.6078    % +1
4	3	200.0010 ]  % +1


% 1.1	Weights

[n_obs columns] = size(obs_mat);
P=eye(n_obs,n_obs);

% Chosing one km measured distance as weight unit, that
% means s_0 = 1 in unit mm implies weight p0 = 1.  
% p0*s0^2 = p1*s1^2 = ....=> p1=1/s1^2

for i=1:n_obs
    sigma_mm(i,1) = 0.5+0.5*obs_mat(i,3)/1000 % [unit mm]
    % sigma_m(i,1) = sigma_mm(i,1)/1000
    P(i,i)=1/(sigma_mm(i,1)^2)   
end

% 1.2	Design matrix A, columns order as the transposed x-vector: [x3,y3,x4,y4]
% 

di = sqrt(100^2+200^2) % diameter

A = [   0           0       0       0       % 1-2   Both fixed points
        100/di      200/di  0       0       % 1-3
        0           0       1       0       % 1-4
        0           0       0       0       % 2-1   Both fixed points
        1           0       0       0       % 2-3
        0           0       100/di  -200/di % 2-4
        100/di      200/di  0       0       % 3-1
        1           0       0       0       % 3-2
        0           1       0       -1      % 3-4
        0           0       1       0       % 4-1
        0           0       100/di  -200/di % 4-2
        0           1       0       -1  ];  % 4-3
        
        
for i=1:12;
 fprintf('%12.8f %12.8f %12.8f %12.8f \n', A(i,:) ); % Skriver til skjerm
end

        
% 1.3   Standard deviations 

Q=inv(A'*P*A);

for i=1:4
    S(i,1)=sqrt(Q(i,i));    % unit is mm
end

S

% 1.4   Standard error ellipse point 3 and 4

Q3(1,1)=Q(1,1);
Q3(1,2)=Q(1,2);
Q3(2,1)=Q(2,1);
Q3(2,2)=Q(2,2);

Q4(1,1)=Q(3,3);
Q4(1,2)=Q(3,4);
Q4(2,1)=Q(4,3);
Q4(2,2)=Q(4,4);

[E3 lambda3] = eig(Q3,'matrix');
[E4 lambda4] = eig(Q4,'matrix');

CI_std_3=sqrt(lambda3(2,2)) % units mm
CI_std_4=sqrt(lambda4(2,2)) 

% Direction of error ellipse, See Reliablility assignment 5 from 2018


% 2.1   redundancy (n-e) = 12-4 = 8

% 2.2   f-vector

f(1,1) = 0.001;
f(2,1) = 0.001;
f(3,1) = 0.001;
f(4,1) = -0.001;
f(5,1) = -0.001;
f(6,1) = -0.001;
f(7,1) = -0.001;
f(8,1) = -0.001;
f(9,1) = -0.001;
f(10,1) = 0.001;
f(11,1) = 0.001;
f(12,1) = 0.001;

% 2.3  estimation

x_hat=Q*(A'*P*f)

p3(1,1)= x(3,1)+x_hat(1,1);    % x point 3
p3(1,2)= y(3,1)+x_hat(2,1);    % y point 3 
p4(1,1)= x(4,1)+x_hat(3,1);    % x point 4
p4(1,2)= y(4,1)+x_hat(4,1);    % y point 4

p3
p4

v_hat=A*x_hat-f
sum_pvv=v_hat'*P*v_hat

so_squared_apost=sum_pvv/(12-4) %
s0_apost=sqrt(so_squared_apost) % unit meter



% 2.4 Error ellipses

C3 = so_squared_apost*Q3 % Covariance matrices after adjustment
C4 = so_squared_apost*Q4 % Covariance matrices after adjustment

[E3 lambda3] = eig(C3,'matrix');
[E4 lambda4] = eig(C4,'matrix');

CI_std_3=sqrt(lambda3(2,2)) % units m
CI_std_4=sqrt(lambda4(2,2)) 

% 2.5
% Difference from 1.4 is the scalefactor S_apost^2, same shape and direction

% 2.6   
% Remove obs 9 (3 to 4)? Give a low weight to obs 9 will give same results

P99 = P(9,9);     % Saving the old value
P(9,9)=0.00000001 % new very low weight
B=Q*A'*P;
x_hat=B*f;

p3(1,1)= x(3,1)+x_hat(1,1);    % x point 3
p3(1,2)= y(3,1)+x_hat(2,1);    % y point 3 
p4(1,1)= x(4,1)+x_hat(3,1);    % x point 4
p4(1,2)= y(4,1)+x_hat(4,1);   % y point 4

d_adjusted = sqrt((p3(1,1)-p4(1,1))^2+(p3(1,2)-p4(1,2))^2)
diff = obs_mat(9,3)-d_adjusted
% OBS This difference should be -0.0016 but becomes -0.0014 with only one
% adjustment, should have made another iteration.....

P(9,9)=P99 % Putting back old weight-value

% 2.7 Redundancy matrix
Q_vv = inv(P) - A*Q*A';
R= Q_vv*P;
I=eye(12,12);
R2=I-A*Q*A'*P;

% 3.1 Multiple T-testing
% 3.2 
% so_squared_apost=sum_pvv/(12-4)

alfa_ind = 1-(1-0.05)^(1/n_obs);
table_df_7 = tinv((1-alfa_ind/2),7);

for i=1:12  % n adjustments in multiple T-Test
% remember, this is not really a free network
c = zeros(12,1);
c(i,1)=1;
A2 = [   A   c   ];
Q2=inv(A2'*P*A2);
B2 =Q2*A2'*P;

x_hat_obs(:,i)=B2*f;
nabla(i,1)=x_hat_obs(5,i);
v_hat_i(:,i)=A2*x_hat_obs(:,i)-f;
s_0_sq(i,1)=(v_hat_i(:,i)'*P*v_hat_i(:,i))/(12-5);% 
C2=s_0_sq(i,1)*Q2;
s_nabla(i,1)=sqrt(C2(5,5));

% T-test
t_comp(i,1)=abs(nabla(i,1)/s_nabla(i,1));
    if (abs(t_comp(i)) > table_df_7)
        fprintf('Significant gross error in obs %4.0f \n', i);
    else
        fprintf('No significant gross error in obs %4.0f \n', i);
    end % End if
% IP
conf_int(i,1)=nabla(i,1)-2.36*s_nabla(i,1);
conf_int(i,2)=nabla(i,1)+2.36*s_nabla(i,1);
if abs(conf_int(i,1)) > abs(conf_int(i,2));
    IP(i,1) = conf_int(i,1);
else
    IP(i,1) = conf_int(i,2);
end % if
IP_one = zeros(n_obs,1);
IP_one(i,1)=IP(i,1);

% [cols, rows]=size(B2);
 
YP=B*IP_one;  % Column vectors of LRE's in order x3,y3,x4,y4
 
P3_def(i,1)=sqrt(YP(1,1)^2+YP(2,1)^2); % point def point 3
P4_def(i,1)=sqrt(YP(3,1)^2+YP(4,1)^2); % point def point 4

end

comp_v=zeros(12,1);
for i=1:12
    comp_v(i,1)=-1*R(i,i)*nabla(i,1);
end

diff_v= comp_v-v_hat

% IP is a vector of Largest Remaining Error for each observation

% 3.5

% Point 3
% max 2D deformation (M3) caused by obs in row no. (I3) 
[M3,I3] = max(P3_def)

[M4,I4] = max(P4_def)


