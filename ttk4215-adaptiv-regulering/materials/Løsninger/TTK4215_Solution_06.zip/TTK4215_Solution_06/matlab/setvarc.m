% System parameters
beta = 0.2;
m = 15;
k=2;

% Filter parameters
lambda0 = 400;
lambda1 = 40;

% Estimator parameters
theta_10 = 0.1; % Initial parameter estimate
min_k = 0.1; % Minimum value for k
theta_20 = [10;0.5]; % Initial parameter estimate
min_m = 10; % Minimum value for m
min_beta = 0; % Minimum value for beta
max_beta = 1; % Maximum value for beta
alpha_1 = 0; % Parameter for normalization
alpha_2 = 0; % Parameter for normalization
gamma_1 = 0.01; % Adaptive gain
Gamma_2 = diag([20000, 10]); % Adaptive gain
