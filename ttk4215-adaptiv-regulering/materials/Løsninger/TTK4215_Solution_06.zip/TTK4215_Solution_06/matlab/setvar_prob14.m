% System parameters
k_0 = 0.82;
w_0 = 20;
zeta_0 = 0.323;

k_1 = 0.055;
w_1 = 14.16;
zeta_1 = 0.318;

% Corresponding theta:
theta_star_0 = [w_0^2; zeta_0*w_0; k_0*w_0^2]
theta_star_1 = [w_1^2; zeta_1*w_1; k_1*w_1^2]

% Filter parameters
lambda0 = 1;
lambda1 = 2;

% Estimator parameters
% Initial guesses
k_0_init = 1;
w_0_init = 22;
zeta_0_init = 0.1;

k_1_init = 0.05;
w_1_init = 15;
zeta_1_init = 0.5;

% Corresponding initial theta:
theta_0 = [w_0_init^2; zeta_0_init*w_0_init; k_0_init*w_0_init^2]; % Initial parameter estimate
theta_1 = [w_1_init^2; zeta_1_init*w_1_init; k_1_init*w_1_init^2]; % Initial parameter estimate


alpha = 0; % Parameter for normalization
ps_beta = 1; % Forgetting factor
P0 = diag([200,100,5]); % Initial covariance matrix (inverse)

theta1_min = 0.1;  % Projection of theta1
theta2_min = 0.1;  % Projection of theta2
