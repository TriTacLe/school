% System parameters
m = 0.2;
l=1;
beta = 0.003;
% Corresponding theta:
theta_star = [1/(m*l^2); 9.81/l; beta/(m*l^2)]

% Filter parameters
lambda0 = 10;
lambda1 = 20;

% Estimator parameters
% Initial guesses
m0 = 0.1;
l0 = 1.2;
beta0 = 0.006;

% Corresponding initial theta:
theta_0 = [1/(m0*l0^2); 9.81/l0; beta0/(m0*l0^2)]; % Initial parameter estimate

alpha = 0; % Parameter for normalization
ps_beta = 1; % Forgetting factor
P0 = diag([100,20,5]); % Initial covariance matrix (inverse)
theta1_min = 0.1;  % Projection of theta1
theta2_min = 0.1;  % Projection of theta2
