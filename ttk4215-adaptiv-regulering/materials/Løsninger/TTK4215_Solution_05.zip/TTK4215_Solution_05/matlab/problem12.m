%% Problem 4.9 c,d,e
%select method: 1: Pure Least-Squares
%               2: Pure Least-squares with covarience resetting
%               3: Least-Squares with forgetting factor
%               4: Modified Least-Squares with forgetting factor
method = 2;

%% Parameters
rho_0 = 2;
rho_1 = 0.1;
P_0 = rho_0*eye(3,3);
beta_forget = 0.1;
R_0 = 5;

%% Model
% System model given by m*y'' + beta*y' + k*y = u
m = 20;
beta = 0.1;
k = 5;

% Define state space model x' = Ax + Bu, where x = [y', y]^T
A = [0, 1; -k/m, -beta/m];
B = [0; 1/m];

%% Filter
% Second order stable filter
% lambda = (s+1)^2 = s^2 +2s +1
lambda = [1, 2, 1];

% Realize filters using three state space models. Remember, we need three filter s^2/(s^2 +2s +1), s/(s^2 +2s +1) og 1/(s^2 +2s +1)
% to generate phi. 
[A_f,B_f,C_f_1,D_f_1] = tf2ss([0, 0, 1],lambda);
[A_f,B_f,C_f_2,D_f_2] = tf2ss([0, 1, 0],lambda);
[A_f,B_f,C_f_3,D_f_3] = tf2ss([1, 0, 0],lambda);


%% Simulation 
h = 0.01;                    % sample time (s)
simTime = 600;               % simulation duration in seconds
N  = simTime/h;              % number of samples

% Memory allocation (more efficient to do this a priori)
t = zeros(1, N);
x = zeros(2, N);
U = zeros(1, N);
theta = zeros(3, N);
theta_star = zeros(3, N); theta_star(:, 1) = [m; beta; k];
x_z = zeros(size(A_f,1), 1);
x_phi = zeros(size(A_f,1), 1);
P = P_0;

% NB: All initial conditions are zero

% Main simulation loop
for n = 1:N-1
    % Generate input
    t(n+1) = n*h;
    u = 10*sin(2*t(n)) + 1*cos(3.6*t(n)) + 20*cos(1*t(n)); 
    U(n) = u;
    
    % Changing mass after t = 20s
    if(t(n) > 20)
        m = 20*(2-exp(-0.01*(t(n) - 20)));
        A = [0, 1; -k/m, -beta/m];
        B = [0; 1/m];
    end
    
    % Save actual model parameters at timestep for comparison later
    theta_star(:, n+1) = [m; beta,; k];
    
    % Simulate actual system
    x_dot = A*x(:, n) + B*U(n);
    x(:, n+1) = x(:, n) + h*x_dot;
    y = x(1, n);
    
    % Calculate z 
    x_z_n = x_z + (A_f*x_z + B_f*U(n))*h; % Euler integration
    z = C_f_1*x_z; % Fetch output
    
    % Calculate phi
    x_phi_n = x_phi + (A_f*x_phi + B_f*y)*h; % Euler integration
    phi = [C_f_3*x_phi + D_f_3*y; C_f_2*x_phi + D_f_2*y; C_f_1*x_phi + D_f_1*y]; % Fetch output
    
    % Normalized estimation error
    m_squared = (1 + phi'*phi); %normalization
    epsilon = (z - theta(:, n)'*phi)/m_squared;
    
    % Calculate P-matrix depending on chosen method
    switch method
        case 1  %1: Pure Least-Squares
            P_dot = -(P*phi*phi'*P)/m_squared;
            P_n = P + P_dot*h;
        case 2  %2: Pure Least-squares with covarience resetting
            
            if min(eig(P)) <= rho_1;
                P_n = P_0;
            else
                P_dot = -(P*phi*phi'*P)/m_squared;
                P_n = P + P_dot*h;
            end
        case 3  %3: Least-Squares with forgetting factor
            P_dot = beta_forget*P -(P*phi*phi'*P)/m_squared;
            P_n = P + P_dot*h;
        case 4  %4: Modified Least-Squares with forgetting factor
            if norm(P) <= R_0
                P_dot = beta_forget*P -(P*phi*phi'*P)/m_squared;
            else
                P_dot = zeros(3,3);
            end
            P_n = P + P_dot*h;
    end
    
    % Propagate parameter estimates using Euler intagration
    theta_dot = P*epsilon*phi;
    theta(:, n+1) = theta(:, n) + theta_dot*h;
    
    % Set variables for next iteration
    x_phi = x_phi_n;
    x_z = x_z_n;
    P = P_n;
end

% Plotting
text = ['Pure Least-Squares                           ';
        'Pure Least-squares with covarience resetting ';
        'Least-Squares with forgetting factor         ';
        'Modified Least-Squares with forgetting factor'];

figure(1);
hold on;
plot(t, theta);
plot(t, theta_star, '--')
grid on;
legend('m', '\beta', 'k');
title(cellstr(text(method, :)));