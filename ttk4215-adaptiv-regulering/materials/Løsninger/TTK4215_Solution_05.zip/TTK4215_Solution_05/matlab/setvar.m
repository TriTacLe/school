% System parameters
beta = 0.2;
m = 15;
k=2;

% Filter parameters
lambda0 = 400;
lambda1 = 40;

% Estimator parameters
theta_10 = 0; % Initial parameter estimate
theta_20 = [0;0]; % Initial parameter estimate
alpha_1 = 0; % Parameter for normalization
alpha_2 = 0; % Parameter for normalization
gamma_1 = 0.01; % Adaptive gain
Gamma_2 = diag([20000, 10]); % Adaptive gain
