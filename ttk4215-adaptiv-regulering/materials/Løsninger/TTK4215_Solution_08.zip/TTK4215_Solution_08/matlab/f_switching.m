close all;
clear;

tau_lim = .5;
sat = @(x) min(max(x, -tau_lim), tau_lim);

% True parameters
m    = 0.2;    % [kg]
l    = 1;      % [m]
g    = 9.81;   % [m/sec^2]
beta = 0.003;

% Linearization
A = [0, 1; g/l, -beta/(m*l^2)];
B = [0; 1/(m*l^2)];

Co = ctrb(A,B)
rank(Co)

Q = diag([1,1]);
R = 1;

[K,S,e] = lqr(A,B,Q,R)

total_energy = @(x) 0.5*m*l^2*x(2).^2 + m*g*l*(1-cos(x(1)));
E_d = 2*m*g*l;

k_s = 0.08; % Swing-up gain
control_fun_swing = @(x) sat(-k_s*x(2)*(total_energy(x)-E_d));
control_fun_lqr   = @(x) sat(-K(1)*(x(1)-pi)-K(2)*x(2));

pendulum_dyn = @(t,x) [x(2); (1/(m*l^2))*(control_fun(x) - beta*x(2) - m*g*l*sin(x(1)))];

x_0 = [pi/20;0];
simTime = 10; % [s]

dt = 0.01; % Sample time for controller. Simulate using ode45 in between updates

t_out = [];
x_out = [];
u_out = [];
E_out = [];
active_controller = [];

% Switch using simple threshold on angle from upright
% Could be improved by using some hysteresis mechanism (like a thermostat).
% Could also switch based on velocity as well.
threshold = cos(20*pi/180);

for i=1:simTime/dt
    % Calculate energy
    E = total_energy(x_0);
    E_tilde = E - E_d;
    E_out(i) = E;
    
    u = 0;
    
    if cos(x_0(1)-pi) >= threshold
        u = control_fun_lqr(x_0);
        active_controller(i) = 1;
    else
        u = control_fun_swing(x_0);
        active_controller(i) = 0;
    end
    
    pendulum_dyn = @(t,x) [x(2); (1/(m*l^2))*(u - beta*x(2) - m*g*l*sin(x(1)))];
    [t,x] = ode45(pendulum_dyn,[dt*(i-1),dt*i],x_0);
    
    x_0 = x(end,:)';
    x_out = [x_out; x(1:end-1,:)]; % Remove last time step to avoid replicated values
    t_out = [t_out; t(1:end-1)];
    u_rep = repmat(u,[1,length(t)-1]);
    u_out = [u_out; u_rep'];
end
% Add last time step at the end
x_out = [x_out; x(end,:)];
t_out = [t_out; t(end)];
u_out = [u_out; u'];


figure
subplot(5,1,1)
plot(t_out,x_out(:,1)*180/pi)
ylabel('q')
subplot(5,1,2)
plot(t_out,x_out(:,2))
ylabel('dq/dt')
subplot(5,1,3)
plot(t_out,u_out)
ylabel('\tau')
subplot(5,1,4)
plot(E_out); hold on
plot([1 length(E_out)],[2*m*g*l, 2*m*g*l]); hold off
ylabel('Total Energy')
subplot(5,1,5)
plot(active_controller)
xlabel('Time [s]')
ylabel('Active controller')

