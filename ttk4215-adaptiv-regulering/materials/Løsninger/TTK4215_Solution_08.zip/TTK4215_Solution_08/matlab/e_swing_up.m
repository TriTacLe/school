close all;
clear;

tau_lim = .5;
sat = @(x) min(max(x, -tau_lim), tau_lim);

% True parameters
m    = 0.2;    % [kg]
l    = 1;      % [m]
g    = 9.81;   % [m/sec^2]
beta = 0.003;

total_energy = @(x) 0.5*m*l^2*x(2).^2 + m*g*l*(1-cos(x(1)));
E_d = 2*m*g*l;

k_s = 0.08; % Swing-up gain
control_fun = @(x) sat(-k_s*x(2)*(total_energy(x)-E_d));

pendulum_dyn = @(t,x) [x(2); (1/(m*l^2))*(control_fun(x) - beta*x(2) - m*g*l*sin(x(1)))];

x_0 = [pi/20;0];
simTime = 50; % [s]
[t,x] = ode45(pendulum_dyn,[0,simTime],x_0);

control_fun  = @(x) sat(-k_s*x(:,2)*(total_energy(x)-E_d));
total_energy = @(x) 0.5*m*l^2*x(:,2).^2 + m*g*l*(1-cos(x(:,1)));

figure
subplot(4,1,1)
plot(t,x(:,1)*180/pi)
ylabel('q')
subplot(4,1,2)
plot(t,x(:,2)*180/pi)
ylabel('dq/dt')
subplot(4,1,3)
plot(t,control_fun(x))
ylabel('\tau')
subplot(4,1,4)
plot(t,total_energy(x)); hold on
plot([t(1) t(end)],[2*m*g*l, 2*m*g*l]); hold off
ylabel('Total Energy')
xlabel('Time [s]')



