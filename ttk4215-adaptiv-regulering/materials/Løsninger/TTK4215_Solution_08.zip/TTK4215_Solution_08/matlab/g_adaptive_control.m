close all;
clear;

tau_lim = .5;
sat = @(x) min(max(x, -tau_lim), tau_lim);

% True parameters
m    = 0.2;    % [kg]
l    = 1;      % [m]
g    = 9.81;   % [m/sec^2]
beta = 0.003;

%% Parameter estimator

% Initial guess for parameter estimates
m0 = 0.1;
l0 = 1.2;
beta0 = 0.006;

% Filter design
a = 1;
b = 1;

num1 = [1, 0, 0];
num2 = [1];
num3 = [-1];
num4 = [-1 0];
den = [1, a+b, a*b];
[A_f,B_f,C_z,D_z] = tf2ss(num1, den)
[~,~,C_phi_1,~] = tf2ss(num2, den)
[~,~,C_phi_2,~] = tf2ss(num3, den)
[~,~,C_phi_3,~] = tf2ss(num4, den)

% Adaptive gain
Gamma = diag([2000, 500, 10]);

%% Simulate
pendulum_dyn = @(t,x) [x(2); (1/(m*l^2))*(control_fun(x) - beta*x(2) - m*g*l*sin(x(1)))];

x_0 = [pi/20;0];
simTime = 25; % [s]

dt = 0.005; % Sample time for controller. Simulate using ode45 in between updates

t_out = [0];
x_out = [x_0'];
u_out = [];
E_out = [];
x_f_out = [];   % filter states
theta_out = []; % estimates
active_controller = [];

% Filter states:
% x_f(1): Internal state for filters 1 and 4 (z and phi_3)
% x_f(2): Internal state for filters 1 and 4 (z and phi_3)
% x_f(3): Internal state for filter 2 (phi_1)
% x_f(4): Internal state for filter 2
% x_f(5): Internal state for filter 3 (phi_2)
% x_f(6): Internal state for filter 3
x_f = [0; 0; 0; 0; 0; 0]; % Initial values
x_f_out = [x_f'];

% Estimates:
% theta(1) (1/(ml^2))
% theta(2) (g/l)
% theta(3) (beta/(ml^2))
theta = [1/(m0*l0^2); g/l0; beta0/(m0*l0^2)]; % Initial estimates
theta_out = [theta'];

% Switch using simple threshold on angle from upright
% Could be improved by using some hysteresis mechanism (like a thermostat).
% Could also switch based on velocity as well.
threshold = cos(20*pi/180);

% Controller parameters
Q = diag([1,1]);
R = 1;
k_s = 0.08; % Swing-up gain

for i=1:simTime/dt
    % Upright equilibrium
    r = pi;
    
    % Certainty-equivalence LQR controller
    A = [0, 1; theta(2), -theta(3)];
    B = [0; theta(1)];
    Co = ctrb(A,B);
    if(rank(Co)~= 2)
        fprintf('Warning. (A,B) not controllable!');
    end
    [K,~,~] = lqr(A,B,Q,R);
    control_fun_lqr   = @(x) sat(-K(1)*(x(1)-r)-K(2)*x(2));
    
    % % Certainty-equivalence swing-up controller
    % Estimate of mgl is given by theta(2)/theta(1)
    mgl_est = theta(2)/theta(1);
    % Estimate of 1/(ml^2) is given by theta(1)
    total_energy_est = @(x) 0.5*(1/theta(1))*x(2).^2 + mgl_est*(1-cos(x(1)));
    E_d = 2*mgl_est;
    control_fun_swing = @(x) sat(-k_s*x(2)*(total_energy_est(x)-E_d));
    
    % Calculate energy
    total_energy_true = @(x) 0.5*m*l^2*x(2).^2 + m*g*l*(1-cos(x(1)));
    E_out(i) = total_energy_true(x_0);
    
    u = 0;
    
    % Use cosine for threshold to account for 2pi-periodicity
    if cos(x_0(1)-r) >= threshold
        u = control_fun_lqr(x_0);
        active_controller(i) = 1;
    else
        u = control_fun_swing(x_0);
        active_controller(i) = 0;
    end
    
    pendulum_dyn = @(x) [x(2); (1/(m*l^2))*(u - beta*x(2) - m*g*l*sin(x(1)))];
    
    x = x_0 + dt*pendulum_dyn(x_0);
    
    % Update parameter estimates
    % z = s^2/Lambda(s) q 
    q = x_0(1);
    tau = u;
    z = C_z*x_f(1:2) + D_z*q;
    % phi_1 = 1/Lambda(s) tau
    phi_1 = C_phi_1*x_f(3:4);
    % phi_2 = -1/Lambda(s) sin(q)
    phi_2 = C_phi_2*x_f(5:6);
    % phi_3 = -s/Lambda(s) q
    phi_3 = C_phi_3*x_f(1:2); % NB: share states with z-filter
    phi = [phi_1; phi_2; phi_3];
    eps = (z-theta'*phi)/(1+phi'*phi);
    dtheta = Gamma*eps*phi;
    % Assuming diagonal Gamma. Decouple gradient with projection.
    min = 0.005;
    if (theta(1) > min) || (dtheta(1) > 0)
        % In valid region or derivative pointing in towards valid region.
        % No correction needed
    else
        dtheta(1) = 0;
    end
    
    % Assuming diagonal Gamma. Decouple gradient with projection.
    if (theta(2) > min) || (dtheta(2) > 0)
        % In valid region or derivative pointing in towards valid region.
        % No correction needed
    else
        dtheta(2) = 0;
    end
    
    % Assuming diagonal Gamma. Decouple gradient with projection.
    if (theta(3) > min) || (dtheta(3) > 0)
        % In valid region or derivative pointing in towards valid region.
        % No correction needed
    else
        dtheta(3) = 0;
    end
    
    dx_f_12 = A_f*x_f(1:2) + B_f*q;
    dx_f_34 = A_f*x_f(3:4) + B_f*tau;
    dx_f_56 = A_f*x_f(5:6) + B_f*sin(q);
    dx_f = [dx_f_12; dx_f_34; dx_f_56];
    
    theta = theta + dt*dtheta; % Forward Euler
    x_f   = x_f   + dt*dx_f;
    
    x_0 = x;
    x_out = [x_out; x']; 
    u_out = [u_out; u];
    t_out = [t_out, i*dt];
    theta_out = [theta_out; theta'];
end


figure
subplot(5,1,1)
plot(t_out,x_out(:,1)*180/pi)
ylabel('q')
subplot(5,1,2)
plot(t_out,x_out(:,2))
ylabel('dq/dt')
subplot(5,1,3)
plot(t_out(1:end-1),u_out)
ylabel('\tau')
subplot(5,1,4)
plot(E_out); hold on
plot([1 length(E_out)],[2*m*g*l, 2*m*g*l]); hold off
ylabel('Total Energy')
subplot(5,1,5)
plot(active_controller)
xlabel('Time [s]')
ylabel('Active controller')

figure
subplot(3,1,1)
plot(t_out,theta_out(:,1)); hold on
plot([t_out(1) t_out(end)],[1/(m*l^2),1/(m*l^2)]); hold off
title('\theta vs \theta^*')
ylabel('\theta_1^* = 1/(ml^2)')
subplot(3,1,2)
plot(t_out,theta_out(:,2)); hold on
plot([t_out(1) t_out(end)],[g/l,g/l]); hold off
ylabel('\theta_{2_1}^* = g/l')
subplot(3,1,3)
plot(t_out,theta_out(:,3)); hold on
plot([t_out(1) t_out(end)],[beta/(m*l^2),beta/(m*l^2)]); hold off
xlabel('Time [s]')
ylabel('\theta_{2_2}^* = \beta/(ml^2)')

