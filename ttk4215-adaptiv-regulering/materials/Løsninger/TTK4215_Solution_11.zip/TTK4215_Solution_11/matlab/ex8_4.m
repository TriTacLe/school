close all;
clear all;

thetastar1=-1;
thetastar2=1;
c=1;
gamma1=1;
gamma2=1;

syms x1 x2 x3
g1 = x1^2;
g2 = x1^2+ 1/2*x2^(8/6) + x3^(7/6);

[u,theta1_dot,theta2_dot] = ex8_4_backstep(g1, g2,c,gamma1,gamma2);

x0=[-1;1;2;0;0];

T=[0:0.01:10];

[T,X]=ode45(@ (t,x) ex8_4_dynamics(t,x,thetastar1,thetastar2,g1,g2,u,theta1_dot,theta2_dot), T, x0);

subplot(1,2,1);
h=plot(T,X);
set(h,'LineWidth',3);
grid;
xlabel('Time');
legend('x_1','x_2','x_3','\theta_1','\theta_2');
subplot(1,2,2);
h=plot(T(1:100),X(1:100,:));
set(h,'LineWidth',3);
grid;
xlabel('Time');
legend('x_1','x_2','x_3','\theta_1', '\theta_2');
