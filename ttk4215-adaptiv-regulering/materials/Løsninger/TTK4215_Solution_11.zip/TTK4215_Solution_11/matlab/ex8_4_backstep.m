function [u,theta1_dot,theta2_dot] = ex8_4_backstep(g1, g2,c,gamma1,gamma2)

syms x1 x2 x3 theta1 theta2

q1 = -c*x1 - theta1 * g1;
z1 = x1;
z2 = x2-q1;
tau1 = gamma1*z1*g1;
tau2 = tau1-gamma1*z2*diff(q1,x1)*g1;
q2 = -z1-c*z2+diff(q1,x1)*(x2+theta1*g1)+diff(q1,theta1)*tau2;
z3 = x3-q2;
tau3 = tau2-gamma1*z3*diff(q2,x1)*g1;
theta1_dot = tau3;
theta2_dot = gamma2*z3*g2;
u = -theta2*g2+diff(q2,x1)*(x2+theta1*g1)+diff(q2,x2)*x3+diff(q2,theta1)*tau3-c*z3-z2-diff(q1,theta1)*diff(q2,x1)*gamma1*z2*g1;
