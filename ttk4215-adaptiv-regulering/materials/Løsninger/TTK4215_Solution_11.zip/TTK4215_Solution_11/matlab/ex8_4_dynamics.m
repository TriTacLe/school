function xdot=ex8_4_dynamics(t,x,thetastar1,thetastar2,g1,g2,u,theta1_dot,theta2_dot)

% syms x1 x2 x3 theta1 theta2
x1=x(1);
x2=x(2);
x3=x(3);
theta1=x(4);
theta2=x(5);

xdot1=eval(subs(x2+thetastar1*g1));
xdot2=eval(subs(x3));
xdot3=eval(subs(u+thetastar2*g2));
th1dot=eval(subs(theta1_dot));
th2dot=eval(subs(theta2_dot));

xdot=[xdot1;xdot2;xdot3;th1dot;th2dot];
