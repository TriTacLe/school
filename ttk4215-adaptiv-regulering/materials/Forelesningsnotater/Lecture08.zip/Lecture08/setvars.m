% Plant parameters
kp=1;
b0=3;
a1=3;
a0=-10;

% MRC parameters
lambda0=2;
T = 1;
lambda0=500;
T=0.01;


% Direct MRAC parameters 
Gamma=diag([1000,100,1000,10]);
theta0=[0;0;0;0];

% LS parameters for indirect MRAC
beta = 1;
alpha = 1;
lambda0_ls=1;
lambda1_ls=2;
theta0_ls = [0.1;-2;2;2];
P_0 = eye(4);

% State space model of plant.
[Ap,Bp,Cp,Dp]=tf2ss([kp kp*b0],[1 a1 a0]);
open_loop_poles=eig(Ap)

x0=[0.1;0];

% Solve for the ideal controller (for comparison with estimates)
S = [1, 0, kp, 0;
     a1, kp, kp*(b0+lambda0), 0;
     a0, kp*b0, kp*b0*lambda0, 0;
     0, 0, 0, 1];
p = [a1-b0-1/T;
     (a1-b0-1/T)*lambda0+a0-b0/T;
     lambda0*(a0-b0/T);
     1/(kp*T)];
theta_star = inv(S)*p

% Calculate closed loop poles.
Ac = [Ap+Bp*theta_star(3)*Cp, Bp*theta_star(1), Bp*theta_star(2);
      theta_star(3)*Cp, -lambda0+theta_star(1), theta_star(2);
      Cp, 0, -lambda0];
eig(Ac)