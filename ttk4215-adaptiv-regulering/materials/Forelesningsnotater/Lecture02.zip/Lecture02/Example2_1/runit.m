
tspan = linspace(0,10,200);
theta0 = 0;

[T,THETA1] = ode45(@(t,x)dynamics(t,x,1),tspan,theta0);
[T,THETA2] = ode45(@(t,x)dynamics(t,x,2),tspan,theta0);

h=plot(T,THETA1, T, THETA2, [0,T(end)],[2,2],'g--');
set(h, 'LineWidth',3);
grid;
xlabel('Time');
ylabel('\theta');
legend({'u=e^{-t}','u=sin(t)','\theta^*'});