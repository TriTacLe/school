function dtheta=dynamics(t,theta,usel)
thetastar = 2;
gamma = 1;

if usel==1
    u = exp(-2*t);
else
    u = sin(3*t);
end
eps = thetastar*u - theta*u;

dtheta = gamma*eps*u;
