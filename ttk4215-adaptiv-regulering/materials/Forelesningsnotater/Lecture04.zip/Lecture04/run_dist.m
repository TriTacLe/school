% System parameters
k_p = 1;

% Disturbance
A1 = 3;
omega_1 = 3;
phi_1 = 2;
A2 = 1;
omega_2 = 5;
phi_2 = 7;

% Controller
Kp = 0.8;  % Proportional gain
Kd = 2;    % Derivative action

% Estimator parameters
theta_0 = [0;0;0;0]; % Initial parameter estimate
alpha = 0;           % Signals are bounded, normalization not neccessary

% Filter constants
lambda_1 = 1;
lambda_2 = 1;

% Gradient method
Gamma = 10*eye(4);   % Adaptive gain.

% Integral cost
beta = 1;            % Forgetting factor for integral cost.
R_0 = zeros(4,4);    % Initial R is always zero.
Q_0 = zeros(4,1);    % Initial Q is always zero.

% Least squares
P_0 = 2*eye(4,4);    % Initial P for LS.
