z0 = 0.1*[1;1];
tspan=0:0.01:200;
figure;
hold;
for d=0.1:0.1:0.5,
    z0 = d*[1;1];
    [T,Z] = ode45(@dynamics, tspan, z0);
    h=plot(Z(1,1),Z(1,2),'o',Z(end,1),Z(end,2),'x',Z(:,1),Z(:,2));
    set(h,'LineWidth',3);
    grid;
end
hold off;
xlabel('x_1');
ylabel('x_2');

function zdot=dynamics(t,z)
    x=z(1);
    y=z(2);

    r = sqrt((x+1)^2+y^2);
    xdot = (x+1)-y-(x+1)*r^2+(x+1)*y/r;
    ydot = (x+1)+y-y*r^2-(x+1)^2/r;

    zdot=[xdot;ydot];
end
