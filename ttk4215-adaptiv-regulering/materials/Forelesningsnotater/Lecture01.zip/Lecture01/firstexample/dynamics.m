function dX=dynamics(t,X)
% X = [x;ahat];
y=X(1);
ahat=X(2);

% System parameter
a=2;

% Controller parameter.
c=1;

% Control input.
u = -ahat * y - c * y; 

% Derivatives
dX = [a*y+u;
      1];
