function dX=dynamics(t,X)
% X = [x;ahat];
x=X(1);
ahat=X(2);

% System parameter
a=2;

% Controller parameter.
c=1;

% Control input.
u = -ahat * x - c * x; 

% Derivatives
dX = [a*x+u;
      x^2];
