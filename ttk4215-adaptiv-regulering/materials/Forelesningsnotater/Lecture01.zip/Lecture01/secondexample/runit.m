% Simulation window
tspan = linspace(0,5,100);

% Initial conditions
x0=1;
a0=0;

% Integrate
[T,X] = ode45(@dynamics,tspan,[x0;a0]);

% Plot results
h=plot(T,X);
set(h, 'LineWidth',3);
grid;
xlabel('Time');
legend('y(t)','â(t)');

figure;
h=plot(T,X(:,1).^2+(X(:,2)-2).^2);
set(h, 'LineWidth',3);
grid;
xlabel('Time');
ylabel('V(x(t))');