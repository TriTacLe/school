% System parameters
k_p = 1;

% Disturbance
A1 = 3;
omega_1 = 3;
phi_1 = 2;
A2 = 1;
omega_2 = 5;
phi_2 = 7;
% No disturbance
%A1 = 0;
%A2 = 0;

% Controller
Kp = 0.8;  % Proportional gain
Kd = 2;    % Derivative action

% Estimator parameters
Gamma = 10*eye(4);  % Adaptive gain.
alpha = 0;    % Signals are bounded, normalization not neccessary
beta = 1;     % Forgetting factor for integral cost.
lambda_1 = 1; % Filter constants
lambda_2 = 1;
theta_0 = [0;0;0;0]; % Initial parameter estimate
R_0 = zeros(4,4);    % Initial R is always zero.
Q_0 = zeros(4,1);    % Initial Q is always zero.
P_0 = 0.1*eye(4,4);    % Initial P for LS.

