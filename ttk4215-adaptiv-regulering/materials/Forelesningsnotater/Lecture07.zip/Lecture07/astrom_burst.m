clear all;
close all;

% System parameters, y(k) = theta* y(k-1)+eta+ u(k-1)
eta=1.4;
theta_star=1.5;

y(1) = 3;
yr=1;

% Parameter estimation
alpha = 10;
gamma = 1;

g0=0.05; % Turns dead-zone on
%g0=0.0; % Turns dead-zone off
theta(1) = 1;
eps(1)=0;
phi(1) = 0;

for k=2:200
    u(k-1) = -theta(k-1)*y(k-1)+yr;
    %u(k-1)=0;
    
    % Advance system
    y(k)=theta_star*y(k-1) + eta + u(k-1);

    % Advance parameter estimation
    m2 = 1+alpha*y(k-1)^2;
    eps(k) = (y(k)-theta(k-1)*y(k-1)-u(k-1))/m2;
    
    % Dead zone
    m = sqrt(m2);
    if abs(eps(k))*m<g0
        g = -eps(k);
    else
        g = -sign(eps(k))*g0/m;
    end

    theta(k)=theta(k-1)+gamma*(eps(k)+g)*y(k-1);
end

% Plot results
figure;
h=plot(y);
set(h,'LineWidth',2);
hold on;
h=plot([1,length(y)],[yr,yr],'--');
set(h,'LineWidth',2);
hold off;
ylabel('y');
grid;
figure;
h=plot(theta');
set(h,'LineWidth',2);
hold on;
h=plot([1,length(theta)],[theta_star,theta_star],'--');
set(h,'LineWidth',2);
hold off;
ylabel('\theta')
grid;

