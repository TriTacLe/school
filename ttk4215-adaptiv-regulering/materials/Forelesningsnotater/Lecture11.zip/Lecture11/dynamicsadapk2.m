function xdot=dynamicsadapk2(t,x,thetastar,c,gamma)

theta=x(3);
fx1=x(1)^2;
dfx1=2*x(1);
q1=-theta*fx1-c*x(1);
z2=x(2)-q1;
thetadot=gamma*(fx1*x(1)+fx1*(theta*dfx1+c)*z2);
u=-c*z2-x(1)-thetadot*fx1+(theta*dfx1+c)*(c*x(1)-z2);
% u=0; % open loop
xdot=[x(2)+thetastar*fx1;u;thetadot];
