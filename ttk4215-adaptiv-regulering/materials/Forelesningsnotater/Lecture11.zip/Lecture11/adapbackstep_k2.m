thetastar=-1;
c=1;
gamma=1;

xinit=[-1;1;0];

T=[0:0.01:10];

[T,X]=ode45(@ (t,x) dynamicsadapk2(t,x,thetastar,c,gamma), T, xinit);

subplot(1,2,1);
h=plot(T,X);
set(h,'LineWidth',3);
grid;
xlabel('Time');
legend('x_1','x_2','\theta');
subplot(1,2,2);
h=plot(T(1:100),X(1:100,:));
set(h,'LineWidth',3);
grid;
xlabel('Time');
legend('x_1','x_2','\theta');
