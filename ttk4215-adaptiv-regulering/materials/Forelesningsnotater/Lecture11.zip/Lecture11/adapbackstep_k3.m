thetastar=-1;
c=1;
gamma=1;

x0=[-1;1;2;0];

T=[0:0.01:10];

[T,X]=ode45(@ (t,x) dynamicsadapk3(t,x,thetastar,c,gamma), T, x0);

subplot(1,2,1);
h=plot(T,X);
set(h,'LineWidth',3);
grid;
xlabel('Time');
legend('x_1','x_2','x_3','\theta');
subplot(1,2,2);
h=plot(T(1:100),X(1:100,:));
set(h,'LineWidth',3);
grid;
xlabel('Time');
legend('x_1','x_2','x_3','\theta');
