function xdot=dynamicsadapk3(t,x,thetastar,c,gamma)

theta=x(4);
fx1=x(1)^2;
q1=-c*x(1)-theta*fx1;
t1=gamma*fx1*x(1);
dfdx1=2*x(1);
d2fdx12=2;
da1dx1=-c-theta*dfdx1;
d2q1dx12=-theta*d2fdx12;
dq1dtheta=-fx1;
d2q1dthetadx1=-dfdx1;
dt1dx1=gamma*dfdx1*x(1)+gamma*fx1;
t2=t1-gamma*(x(2)-q1)*da1dx1*fx1;
q2=-c*(x(2)-q1)-x(1)+da1dx1*x(2)+da1dx1*theta*fx1+dq1dtheta*t2;
dt2dx1=dt1dx1+gamma*da1dx1*da1dx1*fx1-gamma*(x(2)-q1)*(d2q1dx12*fx1+da1dx1*dfdx1);
dq2dx1=c*da1dx1-1+d2q1dx12*x(2)+d2q1dx12*theta*fx1+da1dx1*theta*dfdx1...
    +d2q1dthetadx1*t2+dq1dtheta*dt2dx1;
dt2dx2=-gamma*da1dx1*fx1;
dq2dx2=-c+da1dx1+dq1dtheta*dt2dx2;
dt2dtheta=gamma*dq1dtheta*da1dx1*fx1...
    -gamma*(x(2)-q1)*d2q1dthetadx1*fx1;
dq2dtheta=c*dq1dtheta+d2q1dthetadx1*x(2)+d2q1dthetadx1*theta*fx1+da1dx1*fx1...
    +dq1dtheta*dt2dtheta;
t3=t2-gamma*(x(3)-q2)*dq2dx1*fx1;

u=dq2dx1*(x(2)+theta*fx1)+dq2dx2*x(3)+dq2dtheta*t3-(x(2)-q1)...
    -gamma*(x(2)-q1)*dq1dtheta*dq2dx1*fx1-c*(x(3)-q2);

%u=0; % open loop
xdot=[x(2)+thetastar*fx1;x(3);u;t3];
