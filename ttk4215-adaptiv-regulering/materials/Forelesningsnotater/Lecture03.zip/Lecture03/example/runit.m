% System parameters
b=1;
a=-2;

% Filter parameters
lambda=10;

% Adaptive gain
Gamma=100*eye(2); 

% Nomalization needed since system may be unstable
alpha=0;

% Initial guess
theta_0=[0;0];

% Initial state
y0 = 1;

% Actual parameters
theta_star = [b;a]