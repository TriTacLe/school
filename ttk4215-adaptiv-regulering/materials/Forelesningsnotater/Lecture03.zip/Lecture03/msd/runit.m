% System parameters
m=1;
d=2;
k=3;

% Filter parameters
lambda0=25;
lambda1=10;

% Adaptive gain
Gamma=5000*eye(3);

% Nomalization not necessary since signals are bounded
alpha=0;

% Initial guess
theta_0=[0;0;0];

% Actual parameters
theta_star = [1/m;d/m;k/m]