thetastar=-1;
c=1;
c2=1;

x0=[-1;0];

T=[0:0.01:10];

[T,X]=ode45(@ (t,x) dynamics(t,x,thetastar,c,c2), T, x0);

h=plot(T,X);
set(h,'LineWidth',3);
grid;
xlabel('Time');
legend('x_1','x_2');