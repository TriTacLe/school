function xdot=dynamics(t,x,thetastar,c,c2)

z2=x(2)+thetastar*x(1)^2+c*x(1);
u=-x(1)-(2*thetastar*x(1)+c)*(-c*x(1)+z2)-c2*z2;
%u=0; % open loop
xdot=[thetastar*x(1)^2+x(2);u];
