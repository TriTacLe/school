% Process parameters
thetastar=-1;
x0=-1; % Initial condition.

% Controller parameters
c=1;

% Adaptive law parameters
lambda=5;
gamma=5;
theta0=2; % Initial parameter guess.
