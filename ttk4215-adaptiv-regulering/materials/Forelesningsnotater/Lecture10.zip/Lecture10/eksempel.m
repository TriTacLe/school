% Plant parameters
b_0 = 1;
a_1 = 0;
a_0 = -1.1;

b_bound = 0.5;

% Parameters of predictor form
alpha_0 = a_1^2-a_0;
alpha_1 = a_1 * a_0;
beta_1 = -a_1 * b_0;

% Weighted one-step-ahead-controller
lambda=1;

% Parameter estimate.
Gamma=eye(4); % Adaptive gain.
theta=[b_bound;0;0;0]; % Initial estimate

N = 100; % Number of time steps.

% Reference signal
% y_m = sin([1:102]'/102*6*pi);
y_m = ([1:102]' > 20);
y_p = [1;1]; % Initial y_p.
u_p = [0]; % Initial u_p.

for k=2:N
    % Open loop:
    u_p(k) = 0;

    % One-step-ahead controller
    % u_p(k) = (y_m(k+2) - alpha_0*y_p(k)-alpha_1*y_p(k-1)-beta_1*u_p(k-1))/b_0; 

    % Weighted one-step-ahead controller
    % u_p(k) = b_0*(y_m(k+2) - alpha_0*y_p(k)-alpha_1*y_p(k-1)-beta_1*u_p(k-1))/(b_0^2+lambda); 
    
    % Parameter estimation
    phi = [u_p(max(1,k-2));u_p(max(1,k-3));y_p(max(1,k-2));y_p(max(1,k-3))];
    epsilon = (y_p(k)-theta' * phi)/(1+phi'*phi);
    theta = theta + Gamma * epsilon * phi;
    if sign(b_0)*b_bound < b_bound
        theta(1) = sign(b_0)*b_bound;
    end

    % Adaptive one-step-ahead control
    % u_p(k) = (y_m(k+2) - theta(2:4)'*[u_p(k-1);y_p(k);y_p(k-1)])/theta(1); 

    % Adaptive weighted one-step-ahead controller
    % u_p(k) = theta(1)*(y_m(k+2) - theta(2:4)'*[u_p(k-1);y_p(k);y_p(k-1)])/(theta(1)^2+lambda); 

    % Advance process
    y_p(k+1) = -a_1*y_p(k)-a_0*y_p(k-1)+b_0*u_p(k-1);
end

% Plot results
subplot(2,1,1);
h=plot(y_p);
hold on;
plot(y_m(1:length(y_p)));
hold off;

set(h,'LineWidth',2);
ylabel('y_p');
grid;

subplot(2,1,2);
h=plot(u_p);
set(h,'LineWidth',2);
ylabel('u_p')
grid;
