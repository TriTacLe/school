from flask import Flask, request

app = Flask(__name__)

@app.route("/")
def home():
        return "Welcome to my first Flask app"

@app.route("/login", methods=["POST"])
def login():
        username = request.form.get("username")
        password = request.form.get("password")
        if "<script>" in username or "onerror=" in username:
            return open('flag.txt').read()
        return "Hello {}".format(username)

if __name__ == "__main__":
    app.run()
